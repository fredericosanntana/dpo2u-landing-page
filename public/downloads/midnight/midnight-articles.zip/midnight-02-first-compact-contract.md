---
title: "Your first Compact contract: from pragma to compiled ZK keys"
published: false
description: "A line-by-line tour of a minimal Midnight contract, what `compactc` actually produces when you compile it, and what every file in that build/ directory is for."
tags: midnight, zeroknowledge, compact, tutorial
canonical_url:
cover_image:
series: "Building on Midnight"
---

When you compile a normal smart contract you get bytecode. When you compile a [Compact](https://docs.midnight.network) contract for [Midnight](https://docs.midnight.network) you get bytecode **plus a zero-knowledge proving system** — proving keys, verifying keys, and an intermediate representation of your circuits. The first time you run the compiler and see all those artifacts appear, it's not obvious what any of them do.

This article walks through the smallest useful contract, compiles it, and explains every output. By the end you'll know what `compactc` gives you and why.

## The smallest useful contract

Forget tokens and registries for a second. Here is a complete, valid Compact contract — a payment treasury that accumulates deposits:

```compact
pragma language_version >= 0.21.0;
import CompactStandardLibrary;

export ledger protocol_treasury: Counter;
export ledger total_staked_night: Counter;

export circuit depositToTreasury(amount: Uint<16>): [] {
  assert(amount > 0 as Uint<16>, "Deposit must be greater than zero");
  protocol_treasury.increment(disclose(amount));
}

export circuit stakeTokens(amount: Uint<16>): [] {
  assert(amount > 0 as Uint<16>, "Stake must be greater than zero");
  total_staked_night.increment(disclose(amount));
}

export circuit getTreasuryBalance(): Uint<64> {
  return protocol_treasury;
}
```

That's a real contract from a self-funding-agents project we built. Four things to notice:

**`pragma language_version >= 0.21.0;`** — the version gate. Compact is young and evolving; this line says "refuse to compile unless the language version is at least this." Pin it. A mismatch here is the first error most people hit.

**`import CompactStandardLibrary;`** — pulls in `Counter`, `Map`, hashing helpers, and the types. You'll import this in essentially every contract.

**`export ledger ... : Counter;`** — a `Counter` is a purpose-built ledger type for monotonic counts. It has `increment(n)` and reads back as a `Uint<64>`. Using `Counter` instead of a raw integer is the idiomatic way to express "this only goes up," and it keeps the circuit cheap.

**`disclose(amount)`** — `amount` arrives as a private witness; we make it public before incrementing the public counter. (More on that boundary in its own article.)

## Compiling it

With the Compact toolchain installed, you compile a single file like this:

```bash
compactc PaymentGateway.compact build/PaymentGateway
```

We pin the compiler version in a small wrapper so every contract builds identically:

```bash
COMPILER_VERSION="${COMPACT_VERSION:-0.31.0}"
# compile each .compact -> build/<Contract>/
```

Pinning the compiler version (`0.31.0` here) matters more than it looks. The ZK artifacts a circuit produces are tied to the compiler and language version; if a teammate compiles the same source with a different `compactc`, they can get different keys. Treat the compiler version like a lockfile.

## What ends up in `build/`

This is the part nobody explains. After compiling, `build/PaymentGateway/` contains roughly:

```
build/PaymentGateway/
├── contract/        # TypeScript/JS bindings — what your app imports
│   └── index.*      #   Contract class, circuit call signatures
├── keys/            # ZK proving + verifying keys, one pair per circuit
├── zkir/            # the zero-knowledge intermediate representation
└── ...
```

Map each to what it's for:

- **`contract/`** — the JavaScript bindings. Your dApp does `import * as PaymentGateway from '../build/PaymentGateway/contract/index.js'` and gets a typed `Contract` object with `depositToTreasury`, `stakeTokens`, etc. This is the surface you actually program against.
- **`keys/`** — the **proving key** is used by the prover (or a proof server) to generate a proof that a circuit ran correctly. The **verifying key** is what the chain uses to check that proof. Each circuit gets its own pair. These can be large — proving keys are routinely hundreds of kilobytes.
- **`zkir/`** — the circuit lowered into an arithmetic representation. You rarely touch it by hand, but it's what the keys are generated from.

The generated bindings also embed a runtime-version check — something like `checkRuntimeVersion('0.16.0')` — so that if your installed `compact-runtime` doesn't match what the contract was compiled against, you fail loudly at load time instead of mysteriously at proving time.

## The insight: compiling *is* the trusted setup boundary

Here's the thing worth internalizing. In a normal chain, "compile" is a cheap, throwaway step. On Midnight, compiling your contract is the moment your circuits become a fixed cryptographic object. The verifying key is **pinned by the deployed contract address** — which means no caller can later substitute a different circuit or a malicious verifying key. The privacy and the soundness of your contract are decided at compile-and-deploy time, not at call time.

That has a practical consequence: **changing a circuit changes its keys, which changes the deployed contract.** You can't hot-patch a circuit the way you might tweak a backend function. So get your circuit logic and your public/private split right *before* you compile for a network you care about.

## Try it yourself

1. Install the Compact toolchain and pin a compiler version (we use `0.31.0`).
2. Save the `PaymentGateway` contract above to a file.
3. Compile it and `ls -R build/PaymentGateway`.
4. Open `build/PaymentGateway/contract/index.*` and find the generated names for `depositToTreasury` and `getTreasuryBalance` — those are exactly what you'll call from TypeScript.
5. Look at the size of the files under `keys/`. That heft is the price of zero-knowledge — and it's why a **proof server** exists to do the heavy lifting (a topic for the deployment article in this series).

Once you've seen the build output for a contract you understand line-by-line, the larger contracts stop being intimidating — they're the same shape, just more circuits.

---

*Part of a hands-on series on Compact + Midnight. The `PaymentGateway` contract above is real, compiles on `compactc 0.31.0`, and is exercised by unit tests. Next: the `disclose()` keyword, and exactly what crosses Midnight's privacy boundary.*
