---
title: "Anti-replay on Midnight: building a one-time used-set when Compact has no Set type"
published: false
description: "A valid ZK proof can be replayed unless you bind it to something single-use. Here's how to build a used-set in Compact with a Map, the H(org||jurisdiction||nonce) context pattern, and why this is defense your cryptography alone doesn't give you."
tags: midnight, zeroknowledge, compact, web3
canonical_url:
cover_image:
series: "Building on Midnight"
---

Here's a failure mode that surprises people building their first real [Midnight](https://docs.midnight.network) contract: **a valid zero-knowledge proof is, by itself, replayable.**

If your circuit proves "this company passed compliance," and that's *all* it proves, then nothing stops the same proof from being submitted twice, or an old proof from being resubmitted next year, or the identical attestation being sealed for two different purposes. The math is sound every time — that's the problem. Soundness isn't freshness.

The fix is to bind each proof to a **one-time token** and reject any token you've seen before. In other words, you need a set of "already used" values. And in Compact today, there is no `Set` type. So let's build one.

## A Map *is* a set

The trick is simple: a set is just a map where you only care about the keys. Use a `Map<Bytes<32>, Uint<8>>`, store a throwaway value, and treat `member()` as "is this in the set?"

```compact
export ledger used_contexts: Map<Bytes<32>, Uint<8>>;   // Set semantics (no Set type yet)
```

The comment is load-bearing — it tells the next reader that the `Uint<8>` value is meaningless and this map models a set. To "add to the set," insert with a dummy value of `1`. To "check membership," call `member()`.

## The one-time context

Now, *what* do we put in the set? Not the proof itself — we want to reject a logical duplicate, not just a byte-identical resubmission. So we bind each attestation to a context computed off-chain:

> `context = H(org || jurisdiction || nonce)`

This is domain separation. By hashing the organization, the jurisdiction, and a nonce together, you get a value that is:

- **Unique per logical attestation** — different org, different jurisdiction, or different nonce → different context.
- **Unforgeable to collide** — it's a hash, so you can't engineer two meaningful inputs to the same context.
- **Opaque** — it reveals nothing about the underlying identifiers to an on-chain observer beyond the fact of use.

Here's the enforcement, inside the attestation circuit:

```compact
export circuit attestCompliance(
  company_id: Bytes<32>,
  agent_did: Bytes<32>,
  policy_cid: Bytes<32>,
  threshold: Uint<8>,
  context: Bytes<32>,
  score: Uint<8>
): [] {
  // Anti-replay: a given context (org||jurisdiction||nonce) may be sealed only once.
  assert(!used_contexts.member(disclose(context)), "Replay: context already used");
  assert(score <= 100, "Invalid compliance score, must be bounded to 0-100%");
  assert(score >= threshold, "Score below threshold");

  // Bind the context FIRST — mark it used in the same circuit that consumes it.
  used_contexts.insert(disclose(context), disclose(1 as Uint<8>));
  attestation_verdicts.insert(disclose(company_id), disclose(1 as Uint<8>));
  // ... rest of the public audit trail
  attestation_count.increment(1);
}
```

Read the two context lines together. The `assert(!used_contexts.member(...))` rejects a context that's already in the set. The very next write, `used_contexts.insert(...)`, adds it. Check-then-insert, atomically within one circuit. The second time anyone submits the same context, the assert fails and the whole call aborts. Replay closed.

## Why this is "defense in depth"

You might object: a robust ZK system already prevents naive replay at the protocol level. True to a degree — but there's a meaningful difference between *the chain* preventing duplicate transactions and *your contract* enforcing application-level uniqueness.

The protocol can stop the same transaction bytes from being applied twice. It cannot know that "Acme's LGPD attestation for Q2" is a thing that should happen exactly once. That semantic lives in your domain, so the uniqueness guard has to live in your contract. The used-set is you encoding a business invariant — *one attestation per (org, jurisdiction, nonce)* — into the ledger itself, where it's enforced cryptographically rather than by hopeful off-chain bookkeeping.

This is the kind of guard a purely cryptographic, off-chain-verifier design tends to miss, because it's focused on "is the proof valid?" and not "should this proof be accepted *here, now, again?*"

## Ordering matters

One genuine gotcha: **mark the context used before you do anything that another party could observe and react to.** In our circuit the insert happens right after the membership assert, before the verdict writes. If you scattered the `used_contexts.insert` to the end, after a long sequence of other writes, you'd be widening the window for confusing partial states. Keep check-and-claim adjacent and early. Treat it like taking a lock: acquire it the instant you've verified you're allowed to.

## Try it yourself

1. Add a `used_<thing>: Map<Bytes<32>, Uint<8>>` ledger to any circuit that should run once per logical event.
2. At the top of the circuit: `assert(!used_thing.member(disclose(token)), "replay");`
3. Immediately after: `used_thing.insert(disclose(token), disclose(1 as Uint<8>));`
4. Write two unit tests: submit a fresh token (passes), submit the same token again (aborts with "replay").

Pick your token deliberately. A nonce alone gives you global uniqueness; `H(org || purpose || nonce)` gives you uniqueness scoped to a meaningful event. The hash inputs *are* your uniqueness policy — choose them to match exactly what "this should only happen once" means in your application.

When you reach for a `Set` in Compact and remember there isn't one, this `Map`-as-set with a one-time hashed context is the idiom to reach for instead.

---

*Part of a hands-on series on Compact + Midnight. The contract above is real, compiles on `compactc 0.31.0`, with replay covered by unit tests. Next: how a single audited circuit serves 25 jurisdictions via deterministic `use_case_id` hashing.*
