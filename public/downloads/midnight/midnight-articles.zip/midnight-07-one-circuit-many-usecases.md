---
title: "One audited circuit, many use cases: deterministic IDs in Compact"
published: false
description: "Don't write one circuit per variant. Write one generic attestation circuit, key everything by a deterministic SHA-256 use_case_id, and route every variant through the same audited contract. Here's the pattern and why it scales."
tags: midnight, zeroknowledge, compact, web3
canonical_url:
cover_image:
series: "Building on Midnight"
---

When you have N variants of the same on-chain action — N jurisdictions, N document types, N policy classes — the tempting move is to write N circuits. Resist it. On [Midnight](https://docs.midnight.network), every distinct circuit is a distinct set of proving/verifying keys and a distinct thing to audit. N circuits means N audits, N key sets, and N chances for one of them to be subtly wrong.

There's a better pattern: **one generic circuit, keyed by a deterministic identifier.** We use it to cover 25 compliance jurisdictions through a single audited contract. Here's how it works.

## The generic circuit

Instead of `attestLGPD`, `attestGDPR`, `attestCCPA`, and twenty-two more, we have exactly one circuit that takes the variant as a parameter:

```compact
export ledger usecase_verdicts: Map<Bytes<32>, Uint<8>>;     // evidence_hash -> verdict
export ledger usecase_ids: Map<Bytes<32>, Bytes<32>>;        // evidence_hash -> use_case_id
export ledger usecase_metadata: Map<Bytes<32>, Bytes<32>>;   // evidence_hash -> metadata_hash
export ledger usecase_attestation_count: Counter;

export circuit attestUseCase(
  use_case_id: Bytes<32>,
  verdict: Uint<8>,
  evidence_hash: Bytes<32>,
  metadata_hash: Bytes<32>
): [] {
  assert(verdict <= 2, "Invalid verdict: 0=FAIL, 1=PASS, 2=REVIEW");
  usecase_verdicts.insert(disclose(evidence_hash), disclose(verdict));
  usecase_ids.insert(disclose(evidence_hash), disclose(use_case_id));
  usecase_metadata.insert(disclose(evidence_hash), disclose(metadata_hash));
  usecase_attestation_count.increment(1);
}
```

The `use_case_id` is just a `Bytes<32>`. The circuit doesn't care *which* use case it is — LGPD, GDPR, a medical-records policy, a supply-chain check. It validates the verdict, then seals `verdict + use_case_id + metadata_hash`, keyed by the unique `evidence_hash`. One circuit, one audit, one key set — and it serves every variant you'll ever add.

## The deterministic ID

The magic is in how `use_case_id` is computed. It must be **deterministic**: the same logical use case always maps to the same 32 bytes, on every machine, today and next year, so that an off-chain verifier can independently recompute it and check the on-chain record. We derive it with a domain-separated SHA-256:

```typescript
export const JURISDICTION_CODES = [
  'LGPD', 'GDPR', 'DPDP', 'MICAR', 'MICAR-CASP', 'PDPA', 'UAE', 'POPIA', 'NDPA',
  'CCPA', 'PIPEDA', 'LAW25', 'PIPA', 'PDP', 'APPI', 'MEXICO', 'VIETNAM', 'MALAYSIA',
  'KENYA', 'GHANA', 'COLOMBIA', 'TANZANIA', 'RWANDA', 'UGANDA', 'ARGENTINA',
] as const;

export function useCaseId(code: JurisdictionCode, version = 1): Uint8Array {
  return new Uint8Array(
    createHash('sha256').update(`dpo2u:${code}:compliance:v${version}`).digest(),
  );
}
```

Three design choices in that one function carry a lot of weight:

- **Domain separation** — the string is `dpo2u:LGPD:compliance:v1`, not just `LGPD`. The prefix (`dpo2u:`) and suffix (`:compliance`) namespace the hash so it can't collide with some other system's `LGPD` identifier. If you ever hash user-controlled input, domain separation is what stops cross-context collisions.
- **Versioning** — `v${version}` is baked into the hash. When the LGPD predicate changes meaningfully, you bump to `v2`, and `dpo2u:LGPD:compliance:v2` is a *completely different* 32-byte id. Old attestations stay valid under `v1`; new ones live under `v2`. No migration, no ambiguity.
- **Recomputability** — because it's a pure function of a public string, anyone can recompute the id for any code and verify the chain. The id isn't a secret or a registry lookup; it's `SHA-256` of a string you can publish.

## Why this beats one-circuit-per-variant

Think about what happens when you add jurisdiction #26.

- **One-circuit-per-variant**: write a new circuit, compile new keys, get it audited, deploy a new contract, update every client to know about it. Five steps, each a chance to introduce drift or a bug.
- **Generic circuit**: add one string to the `JURISDICTION_CODES` array. That's it. The circuit, keys, contract, and audit are unchanged because *nothing about the circuit changed*. The new jurisdiction is just a new `use_case_id` flowing through the same proven code.

This is the same instinct as preferring data over code. The variation lives in *data* (a hash derived from a string) rather than in *code* (a bespoke circuit). Data is cheap to add and impossible to mis-audit; circuits are neither.

There's a security dividend too: a single circuit means a **single attack surface**. Auditors review one `attestUseCase`, not twenty-five near-identical circuits where #17 has a typo nobody caught. Concentrating the logic concentrates the scrutiny.

## When *not* to do this

Honesty check: this works when the variants share the *same shape of computation* — here, "seal a verdict + hashes." If a variant needs genuinely different *constraints* (a different predicate, different witnesses, different math), forcing it through the generic circuit means smuggling that logic off-chain and trusting it, which can defeat the point. The generic-ID pattern is for variants that differ in *identity and metadata*, not in *what must be proven*. When the proof obligation itself differs, that variant earns its own circuit.

## Try it yourself

1. Write one generic circuit that takes a `kind_id: Bytes<32>` and seals a result keyed by a unique hash.
2. Write a small helper that maps your variant names to ids: `sha256("yourapp:" + name + ":v1")`.
3. Add three variants by adding three strings — no contract change.
4. Prove the round-trip: compute `use_case_id` off-chain for a variant, submit an attestation, then read it back and confirm the on-chain `use_case_id` equals what you computed. That equality is the whole guarantee.

One audited circuit that scales by adding strings is one of the highest-leverage patterns on Midnight. Reach for it whenever you catch yourself about to copy-paste a circuit.

---

*Part of a hands-on series on Compact + Midnight. The circuit and the 25-code mapping above are real; the contract compiles on `compactc 0.31.0` and a unit test seals a verdict for every jurisdiction through the one circuit. Next: $NIGHT and $DUST — how Midnight's dual-token model funds your dApp's proofs.*
