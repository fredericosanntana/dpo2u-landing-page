---
title: "$NIGHT and $DUST: how Midnight's dual-token model funds your dApp's proofs"
published: false
description: "Midnight separates the token you hold ($NIGHT) from the resource you spend on transactions ($DUST). Here's what that means in practice, why it enables 'self-funding' agents, and the headless flow for generating DUST from staked NIGHT."
tags: midnight, zeroknowledge, compact, web3
canonical_url:
cover_image:
series: "Building on Midnight"
---

The first time you try to submit a transaction on [Midnight](https://docs.midnight.network) and it tells you you have plenty of `NIGHT` but zero `DUST`, you'll be confused. You have tokens! Why can't you pay for the transaction?

Because Midnight deliberately splits two jobs that other chains conflate:

- **$NIGHT** — the token you *hold*. Value, stake, the thing with a balance.
- **$DUST** — the resource you *spend* to transact. It's generated over time by holding (registering) NIGHT, and consumed as you use the network.

If you come from a one-token chain, the analogy is: NIGHT is your capital; DUST is the "energy" your capital slowly produces, which you burn to act. You don't spend NIGHT to transact — you spend DUST, and DUST regenerates as long as you hold NIGHT. It's closer to a resource-regeneration model than a gas-balance model.

## Why split them?

Two reasons that matter for builders.

**Privacy.** On a single-token chain, paying gas links your funding source to your action. The dual model lets the spendable resource (DUST) be decoupled from the value you hold (NIGHT), which fits a privacy chain's whole reason for existing.

**Sustainable usage.** Because DUST regenerates from held NIGHT rather than being bought per-transaction, an account that holds NIGHT has an ongoing, renewable capacity to transact. That's the key that unlocks something interesting: an autonomous service can fund *its own* operation indefinitely, without a human topping up a gas tank.

## The "self-funding" loop

That last point is what we built on. The idea: an agent that earns NIGHT for doing work, stakes it, generates DUST from it, and spends that DUST on the very proofs its work requires — a closed loop that needs no external gas subsidy.

The on-chain primitives are deliberately small. Staking and treasury:

```compact
export ledger protocol_treasury: Counter;
export ledger total_staked_night: Counter;

export circuit stakeTokens(amount: Uint<16>): [] {
  assert(amount > 0 as Uint<16>, "Stake must be greater than zero");
  total_staked_night.increment(disclose(amount));
}
```

And a fee split that pays the participants who did the work — here a fixed 40/60 between an "expert" and an "auditor", enforced *in the circuit*:

```compact
export circuit distributeComplianceFee(
  expert_share: Uint<16>,
  auditor_share: Uint<16>
): [] {
  assert(expert_share > 0 as Uint<16>, "Expert share must be > 0");
  assert(auditor_share > 0 as Uint<16>, "Auditor share must be > 0");
  // Enforce 40/60 ratio: expert * 3 == auditor * 2
  assert(disclose(expert_share) * 3 == disclose(auditor_share) * 2, "Must be 40/60 split");
  expert_fee_pool.increment(disclose(expert_share));
  auditor_fee_pool.increment(disclose(auditor_share));
  total_distributed.increment(disclose(expert_share + auditor_share as Uint<16>));
}
```

Notice the ratio is enforced as `expert * 3 == auditor * 2` rather than computed on-chain. That's a small but instructive trick: rather than do division inside a circuit (awkward and lossy with integers), you let the caller propose the split and the circuit *verifies* it with a cross-multiplication. `40*3 == 60*2` → `120 == 120`. ✓. The contract never divides; it checks. Pushing the arithmetic off-chain and verifying it on-chain is a recurring Compact idiom worth keeping in your toolkit.

## The part the docs gloss over: getting DUST in a headless flow

Here's the operational reality that bites you in automation. When you fund a fresh wallet from a faucet, you receive **unshielded NIGHT** — and `DUST: 0`. NIGHT sitting in your wallet doesn't automatically make DUST. You have to **register your NIGHT UTxOs for dust generation**, then *wait* for DUST to accrue before you can pay for anything.

The canonical headless sequence looks like this:

```
register NIGHT UTxOs for dust generation
  -> finalizeRecipe
  -> submitTransaction
  -> wait until dust.balance(now) > 0n
```

In code, the registration step:

```typescript
const recipe = await wallet.registerNightUtxosForDustGeneration(nightUtxos, vk, signFn);
const tx = await wallet.finalizeRecipe(recipe);
const txId = await wallet.submitTransaction(tx);
// then poll wallet.state() until dust.balance(new Date()) > 0n  (~1-2 min)
```

The gotcha that costs people an afternoon: **you cannot pay for the registration's downstream effects with DUST you don't have yet.** The registration itself is structured so it can go through, but any *subsequent* fee-paying transaction must wait for DUST to actually accrue — which takes a minute or two of wall-clock time. If your deploy script fires transactions immediately after registering, they fail with insufficient DUST and you'll swear the network is broken. It isn't; DUST just hasn't regenerated yet. Poll for `dust.balance(now) > 0n` and proceed only then.

## An honest note on maturity

This dual-token economy is genuinely powerful, but it's also new. In our own work, the staking and fee-split circuits **compile and are unit-tested**, and we've driven the full stake → attest → fee-split loop against a **local Midnight node**. We have *not* run it as a live economic system on a public network. If you're designing tokenomics on top of DUST regeneration, prototype the mechanics locally first and measure real accrual timing before you promise anyone an SLA. The primitives are real; the economic tuning is empirical.

## Try it yourself

1. Spin up a local node and proof server, fund a wallet, and check its state — note `NIGHT > 0`, `DUST == 0`.
2. Call `registerNightUtxosForDustGeneration`, submit, and poll `dust.balance(new Date())` until it's positive. Time it. That number is your real "cold start."
3. Only *after* DUST is positive, submit a contract call. Watch it succeed where an immediate call would have failed.

Once you've felt the NIGHT-held → DUST-regenerates → DUST-spent cycle with your own wallet, the dual-token model stops being a quirk and starts being the feature that makes autonomous, self-funding services possible.

---

*Part of a hands-on series on Compact + Midnight. The staking and fee circuits above are real and unit-tested; the loop has been exercised on a local node, not a public network. Next: actually deploying these contracts with midnight.js — the proof server, the providers, and the preprod sync gotcha.*
