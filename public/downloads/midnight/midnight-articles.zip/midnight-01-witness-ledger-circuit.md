---
title: "The Midnight mental model: witness, ledger, and circuit"
published: false
description: "The three words that unlock Compact. Once you can say which data is a witness, which is ledger, and what the circuit proves, every Midnight contract reads cleanly. Worked through a real privacy-preserving compliance contract."
tags: midnight, zeroknowledge, compact, web3
canonical_url:
cover_image:
series: "Building on Midnight"
---

Most developers arriving at [Midnight](https://docs.midnight.network) come from one of two places: a public-chain background (Solidity, where *everything* on-chain is public) or a backend background (where "the database" is just private). Midnight is neither, and the confusion that follows is almost always the same confusion: **which data is secret, which data is public, and what exactly is being proven?**

Compact — Midnight's smart-contract language — answers that with three concepts. Get these three straight and the rest of the language stops fighting you.

1. **Witness** — private input. Known to the prover, never revealed, never written anywhere public.
2. **Ledger** — public on-chain state. Everyone can read it.
3. **Circuit** — the computation that runs over both, and produces a zero-knowledge proof that it ran correctly.

Let me make these concrete with a contract we actually built: a compliance attestation registry. Its whole job is to prove a company passed a compliance check **without revealing the score**.

## The three concepts, in one contract

Here is the ledger declaration — the public state:

```compact
// Public, on-chain audit trail. The score itself is never part of this state.
export ledger attestation_verdicts: Map<Bytes<32>, Uint<8>>;     // company_id -> 1 (passed)
export ledger attestation_thresholds: Map<Bytes<32>, Uint<8>>;   // company_id -> public threshold met
export ledger attestation_contexts: Map<Bytes<32>, Bytes<32>>;   // company_id -> public anti-replay context
export ledger attestation_count: Counter;
```

Everything marked `export ledger` is world-readable. There is a verdict (`1` = passed), the threshold the company had to clear, and a count. Notice what's **not** there: there is no `attestation_scores` ledger. That omission is the entire point of the design, and it's enforced by the next piece.

Here is the circuit:

```compact
export circuit attestCompliance(
  company_id: Bytes<32>,
  agent_did: Bytes<32>,
  policy_cid: Bytes<32>,
  threshold: Uint<8>,
  context: Bytes<32>,
  score: Uint<8>        // <-- this is the witness
): [] {
  // Proof-public predicate: prove score >= threshold WITHOUT disclosing the score.
  assert(score >= threshold, "Score below threshold");
  // Bind the context and write the public audit trail. The score is never written.
  attestation_verdicts.insert(disclose(company_id), disclose(1 as Uint<8>));
  attestation_thresholds.insert(disclose(company_id), disclose(threshold));
  attestation_contexts.insert(disclose(company_id), disclose(context));
  attestation_count.increment(1);
}
```

`score` is a parameter, but it never reaches the ledger. The circuit `assert`s `score >= threshold` and then writes only the *verdict*. Because the proof is a zero-knowledge proof, a verifier learns that the assertion held — that some score cleared the threshold — and learns nothing else about the score. That is the witness: present during proving, absent from everything public.

## The mental shift

Here's the insight that takes a while to land if you're coming from Solidity: **circuit parameters are not automatically public.** In an EVM contract, every argument you pass to a function is visible in the transaction calldata forever. In Compact, a circuit argument is a *private witness by default*. It only becomes public when you explicitly hand it across the boundary.

That boundary is the `disclose(...)` call. Look again — `company_id`, `threshold`, and `context` are wrapped in `disclose()` before being written; `score` never is. The compiler will actually stop you if you try to write a witness to the ledger without disclosing it. The privacy is structural, not a convention you have to remember.

(We have a whole article just on `disclose()` later in this series, because it's the single keyword newcomers trip on most.)

## Why three concepts and not two

You might ask: why not just "private state" and "public state"? Because the **circuit** is doing something a database can't — it's producing a portable proof. The split looks like this:

| | Lives where | Who sees it | Example in our contract |
|---|---|---|---|
| **Witness** | In the proof, then gone | Only the prover | `score` |
| **Ledger** | On-chain | Everyone | `attestation_verdicts`, `attestation_count` |
| **Circuit** | The proven computation | Verifier sees only that it held | `attestCompliance` proving `score >= threshold` |

Once you can label every value in a contract with one of those three words, you can read any Compact contract. When you see a circuit parameter, ask: *does this get `disclose()`d, or does it stay a witness?* When you see `export ledger`, know it's public forever. When you see `assert(...)`, know that's a constraint the proof guarantees.

## Try it yourself

Take any data model you'd normally put in a database and split each field into one of the three buckets:

- **Witness**: the sensitive raw value (a salary, a score, a medical flag, a balance).
- **Ledger**: the *fact* you want provable (passed / failed, over-18 / not, solvent / not).
- **Circuit**: the predicate connecting them (`salary >= 50000`, `age >= 18`, `assets >= liabilities`).

Then write the three-line skeleton:

```compact
export ledger result: Map<Bytes<32>, Uint<8>>;

export circuit prove(id: Bytes<32>, secret: Uint<64>, threshold: Uint<64>): [] {
  assert(secret >= threshold, "predicate failed");
  result.insert(disclose(id), disclose(1 as Uint<8>));
}
```

If you can write that for your own use case, you understand Midnight's core model. Everything else — maps, counters, anti-replay, deployment — is detail on top of these three words.

---

*This is part of a hands-on series on building privacy-preserving contracts with Compact on Midnight. The code above is from a real compliance-attestation contract (compiles on `compactc 0.31.0`, covered by unit tests). Next up: writing your very first Compact contract from `pragma` to compiled ZK keys.*

*Official docs: [docs.midnight.network](https://docs.midnight.network).*
