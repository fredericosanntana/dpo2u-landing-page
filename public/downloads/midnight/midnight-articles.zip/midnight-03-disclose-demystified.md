---
title: "disclose() demystified: what crosses Midnight's privacy boundary"
published: false
description: "disclose() is the one Compact keyword newcomers trip on. It's not encryption and it's not a no-op — it's an explicit, auditable declaration that a private value is leaving the circuit. Here's the mental model and the rules."
tags: midnight, zeroknowledge, compact, web3
canonical_url:
cover_image:
series: "Building on Midnight"
---

If you've written one [Compact](https://docs.midnight.network) contract, you've met `disclose()`. And if you're like most people, your first reaction was either "why do I have to wrap everything in this?" or "is this encrypting my data?" Neither — and the misunderstanding causes real bugs, so let's nail it down.

## What `disclose()` actually means

In Compact, the arguments to a circuit are **private by default**. They are witnesses — known to the prover, sealed inside the zero-knowledge proof, invisible to everyone else. (If that sentence didn't land, read the [witness/ledger/circuit](#) article first.)

The moment you want to take one of those private values and make it **public** — write it to the ledger, return it from a public read, or use it in a way that leaks it — the compiler forces you to say so, in writing, with `disclose()`.

So `disclose(x)` means exactly one thing:

> "I, the contract author, am intentionally declaring that the value `x` crosses from private to public here. This is not an accident."

It does not encrypt. It does not hash. It does not protect anything. It is the **opposite** of protection — it's the controlled doorway out of the private world. The compiler refuses to let a witness become public *implicitly*, so every leak in your contract is grep-able.

## Seeing it in a real circuit

Here's a compliance attestation circuit. Watch which arguments get disclosed and which don't:

```compact
export circuit attestCompliance(
  company_id: Bytes<32>,
  agent_did: Bytes<32>,
  policy_cid: Bytes<32>,
  threshold: Uint<8>,
  context: Bytes<32>,
  score: Uint<8>
): [] {
  assert(!used_contexts.member(disclose(context)), "Replay: context already used");
  assert(score <= 100, "Invalid compliance score, must be bounded to 0-100%");
  assert(score >= threshold, "Score below threshold");

  used_contexts.insert(disclose(context), disclose(1 as Uint<8>));
  attestation_verdicts.insert(disclose(company_id), disclose(1 as Uint<8>));
  attestation_dids.insert(disclose(company_id), disclose(agent_did));
  attestation_thresholds.insert(disclose(company_id), disclose(threshold));
  attestation_contexts.insert(disclose(company_id), disclose(context));
  attestation_count.increment(1);
}
```

Count the disclosures. `company_id`, `agent_did`, `policy_cid`, `threshold`, and `context` all get `disclose()`d — they become part of the public audit trail. But `score`? **`score` is never disclosed.** It's used in two assertions (`score <= 100` and `score >= threshold`) and then it's gone. The proof attests that those assertions held; the value itself never leaves.

That is the whole "score-private, proof-public" trick, and `disclose()` is what makes it auditable. A reviewer can read this circuit and verify the privacy claim by checking a single thing: *is `score` ever passed to `disclose()`?* It isn't. Claim verified.

## The rule of thumb

Here's the heuristic I give people:

> **`disclose()` should appear on the boundary, never in the middle.**

Use private witnesses freely inside your circuit — compute with them, compare them, branch on them in assertions. Only `disclose()` a value at the exact point where its publicness is *required*: writing to a ledger map, returning it from a public read circuit, or using it as a public key in a lookup.

And a corollary that catches people:

> **Disclosing a value derived from a secret can leak the secret.**

If you compute `H(secret)` and disclose the hash, you've published a commitment to the secret — fine if that's what you want (it's how anti-replay sets work), but think about it. If you disclose `secret > 0 ? 1 : 0`, you've leaked one bit about the secret. `disclose()` is honest about *that this value* becomes public; it can't reason about whether that value lets someone infer your witness. That's your job as the designer.

## Why this design is good, actually

Coming from other ecosystems, mandatory `disclose()` feels like boilerplate. It isn't. Compare the failure modes:

- **In an EVM contract**, leaking private data is the default. You have to *remember* not to emit it, not to store it, not to log it. Forget once and it's public forever. The safe path requires constant vigilance.
- **In Compact**, leaking is impossible *unless you type the word `disclose`*. The safe path is the path of least resistance. A privacy bug becomes a visible, reviewable, greppable token in the source — not an absence you have to notice.

This is the same philosophy as Rust's `unsafe`: make the dangerous thing explicit and searchable rather than implicit and forgettable. For a privacy chain, that's exactly the right default.

## Try it yourself

1. Take the `attestCompliance` circuit above and try to write `score` to a ledger map (`attestation_scores.insert(company_id, score)`). The compiler will reject it until you `disclose(score)` — feel the guard rail push back.
2. Now ask whether you *should* disclose it. (You shouldn't — that defeats the contract's purpose.) This is the design conversation `disclose()` forces you to have, every time.
3. Audit a contract you didn't write by grepping for `disclose`. Every match is a public-output decision. The set of those matches **is** the contract's privacy surface.

When `disclose()` stops feeling like ceremony and starts feeling like the privacy audit writing itself, you've internalized Midnight's core safety model.

---

*Part of a hands-on series on Compact + Midnight. The circuit above is from a real compliance contract (compiles on `compactc 0.31.0`, unit-tested). Next: a real bug — why a read circuit reverts, and the `member()` guard that fixes it.*
