---
title: "The Map.lookup trap: why your Compact read circuit reverts, and the member() guard"
published: false
description: "A real bug we shipped and fixed: in Compact, Map.lookup on a missing key aborts the circuit. Here's why, how it bites read paths specifically, and the member()-guard pattern that makes reads safe."
tags: midnight, zeroknowledge, compact, web3
canonical_url:
cover_image:
series: "Building on Midnight"
---

This one cost us real debugging time, so I'm writing it down so it costs you none.

In [Compact](https://docs.midnight.network), `Map.lookup(key)` on a key that **does not exist** does not return null, does not return a zero value, and does not return some "empty" sentinel. It **aborts the circuit.** The whole call fails.

If you come from Solidity — where reading a missing mapping key cheerfully hands you `0` — this is a trap waiting for you. And it bites hardest in the place you least expect: your read-only query circuits.

## The bug, concretely

We have a consent registry — an LGPD/GDPR consent ledger that tracks whether a data subject has granted or revoked consent. Subjects are keyed by a hash, and the status is `0` (no record), `1` (active), or `2` (revoked).

The natural way to write the "get status" read is:

```compact
// WRONG — aborts for any subject who was never registered
export circuit getConsentStatus(subject_id: Bytes<32>): Uint<8> {
  return consent_status.lookup(disclose(subject_id));
}
```

This looks completely reasonable. It works in every test where the subject exists. Then someone queries a subject who never granted consent — the single most common query in the entire system, because checking "do we have consent?" *before* you have any record is the whole point — and the circuit aborts. Not "returns 0." Aborts.

The intent was "return 0 for unknown subjects." The behavior was "explode for unknown subjects." Those are very different, and the gap is exactly the EVM intuition betraying you.

## The fix: guard with `member()`

`Map` exposes `member(key)`, which returns a boolean: does this key exist? So you check first, and only `lookup` when you know it's safe:

```compact
// Query: get consent status for a subject (0=none, 1=active, 2=revoked).
// Returns 0 for unknown subjects (Map.lookup requires the key to exist, so guard with member).
export circuit getConsentStatus(subject_id: Bytes<32>): Uint<8> {
  if (consent_status.member(disclose(subject_id))) {
    return consent_status.lookup(disclose(subject_id));
  } else {
    return 0 as Uint<8>;
  }
}
```

That's the pattern. `member()` to ask "is it there?", `lookup()` only inside the `true` branch, an explicit default in the `else`. Every read path that touches a `Map` needs this. We apply it uniformly — once we got bitten, we audited every query circuit across every contract and wrapped each one.

## Why it bites *reads* specifically

Write paths usually don't hit this, because writes use `insert` (which is happy to create a key) or they `assert(map.member(key), ...)` up front as a precondition. Look at the revoke circuit in the same contract:

```compact
export circuit revokeConsent(subject_id: Bytes<32>): [] {
  assert(consent_status.member(disclose(subject_id)), "No consent record found for this subject");
  consent_status.insert(disclose(subject_id), disclose(2 as Uint<8>));
  consent_purposes.insert(disclose(subject_id), disclose(0 as Uint<8>));
  total_revocations.increment(1);
}
```

Here a missing key is genuinely an error — you can't revoke consent that was never granted — so the `assert` is correct behavior. The `member()` check is doing precondition duty.

The read path is different: a missing key is **not** an error, it's the legitimate "no record yet" case. Same `member()` primitive, opposite intent. That asymmetry is why the bug hides — your write circuits are accidentally safe, so the contract passes early tests, and only the read path is quietly fragile.

## The deeper reason

Why does Compact abort instead of returning a default? Because there's no universally correct default. A zero-knowledge circuit has to produce a deterministic, well-defined result for the proof to mean anything; "return the zero value of whatever type" is a Solidity convenience that hides a decision. Compact forces you to make that decision explicitly — *you* say what "missing" means for *your* data (`0`? a sentinel? an abort?). It's the same philosophy as `disclose()`: make the implicit thing explicit.

Once you see it that way, the `member()` guard isn't defensive boilerplate — it's you documenting, in code, what absence means in your domain.

## Try it yourself

1. Write a `Map<Bytes<32>, Uint<8>>` ledger and a naive `get(key)` circuit that just does `lookup`.
2. Write two unit tests: one that queries a key you inserted, one that queries a key you never touched.
3. Watch the second test abort. (This is the test most people forget to write — the "nothing here yet" case.)
4. Add the `member()` guard with an explicit default, and watch it return your default instead.

A good rule to adopt from day one: **every `lookup` in a read circuit is guarded by a `member`, or it's a latent abort.** Grep your contracts for `.lookup(` and make sure each one is either inside a `member()` branch or preceded by an `assert(...member...)`. It's a five-minute audit that saves an afternoon.

---

*Part of a hands-on series on Compact + Midnight. The consent contract above is real, compiles on `compactc 0.31.0`, and the unknown-subject case is now an actual unit test. Next: the score-private / proof-public pattern — proving `score >= threshold` without revealing the score.*
