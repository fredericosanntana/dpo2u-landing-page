# Midnight content pack — how to publish + submit to Zealy

10 technical articles + 10 explainer videos on the Midnight blockchain, all in English, grounded in our real Compact contracts and wallet work. Built for two recurring Zealy quests:

- **Publish a technical blog/tutorial** — 250 XP, daily. Needs original teaching + code snippets that help devs understand Midnight.
- **Publish an explainer video** — 200 XP, daily. Needs a clear, publicly-accessible explanation of a Midnight concept.

Each article has a matching video on the same topic, so one topic feeds both quests.

## What's in this pack

- `midnight-01..10-*.md` — DEV.to-ready Markdown (frontmatter included; `published: false` so you control go-live).
- Videos hosted at `https://dpo2u.com/downloads/midnight/midnight-NN-<slug>.mp4` (also in this pack if downloaded).

## How to publish an article (per quest)

1. Open the `.md` in the DEV.to editor (or paste the body into your own blog).
2. In the frontmatter: set `published: true`, and set `canonical_url` to your own-blog copy if you cross-post (recommended — the quest suggests DEV.to **and** your own platform).
3. The `tags:` line is already filled (max 4, DEV.to-valid). Adjust if you like.
4. Publish, copy the public URL, and submit it to the Zealy "technical blog/tutorial" quest.

## How to publish a video (per quest)

The quest needs a **public link**. Two options:

- **YouTube (recommended):** upload the MP4 (unlisted or public is fine), title it with the article title, paste a 1-line topic description, and submit the YouTube URL to the Zealy "explainer video" quest.
- **Direct link:** the hosted `https://dpo2u.com/downloads/midnight/...mp4` URL is already public and can be submitted as-is if you prefer not to use YouTube.

## Honesty note (deliberate)

Every claim in these pieces is true to what we've actually built: the contracts **compile** on `compactc 0.31.0` and pass **53 unit tests**; the self-funding loop has run on a **local node**. Nothing claims a public-testnet/mainnet deployment we don't have (preprod is honestly described as blocked by the history-sync OOM). This both respects the facts and protects against the quest's "primarily promotion / repeats docs" rejection criterion — the value is the original explanation, not a pitch.

## Suggested cadence

Both quests are **daily**. You can drip one article + one video per day for ~10 days (steady XP, looks organic), or publish in a couple of batches. Your call.
