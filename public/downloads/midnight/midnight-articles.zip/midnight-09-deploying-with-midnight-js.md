---
title: "Deploying Compact contracts with midnight.js: the proof server, providers, and the sync gotcha"
published: false
description: "A practical map of what it actually takes to deploy a Compact contract: the proof server, the five providers midnight.js wants, and the preprod history-sync that quietly OOMs Node. Real config, real workarounds."
tags: midnight, zeroknowledge, compact, web3
canonical_url:
cover_image:
series: "Building on Midnight"
---

You've written a [Compact](https://docs.midnight.network) contract and compiled it. Now you want it on-chain. This is the step where the privacy machinery becomes visible, because deploying a zero-knowledge contract needs more moving parts than a normal chain: something has to *generate proofs*, something has to *read public chain state*, something has to *store private state locally*, and something has to *sign and submit*. `midnight.js` wires these together as **providers**. Let's demystify them.

## The proof server

First, the piece with no analog on a transparent chain: the **proof server**. Generating a zero-knowledge proof is computationally heavy, so it runs as a separate service (commonly a local Docker container on port `6300`) rather than inside your app process.

```typescript
proofServer: process.env.PROOF_SERVER_URL ?? 'http://127.0.0.1:6300',
```

Your deploy doesn't generate proofs in-process; it ships the circuit witness to this server, which returns a proof. Rule of thumb: **the proof server version must match your contract's toolchain generation.** A mismatch here produces some of the most confusing errors in the ecosystem, because the failure surfaces at proving time, far from its cause.

## The five providers

`midnight.js` deploys through a bundle of providers, each owning one responsibility. Here's the set, assembled in one place:

```typescript
function makeProviders(walletProvider, cfg, zkPath, storeName, accountId) {
  const zkConfigProvider = new NodeZkConfigProvider(zkPath);
  return {
    privateStateProvider: levelPrivateStateProvider({
      privateStateStoreName: storeName,
      privateStoragePasswordProvider: () => process.env.PRIVATE_STATE_PASSWORD ?? '...',
      accountId,
    }),
    publicDataProvider: indexerPublicDataProvider(cfg.indexer, cfg.indexerWS),
    zkConfigProvider,
    proofProvider: httpClientProofProvider(cfg.proofServer, zkConfigProvider),
    walletProvider,
    midnightProvider: walletProvider,
  };
}
```

What each one is *for*:

| Provider | Responsibility |
|---|---|
| `privateStateProvider` | Stores your contract's **private** state locally (LevelDB). This never goes on-chain. |
| `publicDataProvider` | Reads **public** ledger state via the indexer (HTTP + WebSocket). |
| `zkConfigProvider` | Loads the ZK keys/config for your circuits from the `build/<Contract>` directory. |
| `proofProvider` | Talks to the proof server to actually generate proofs. |
| `walletProvider` / `midnightProvider` | Balances, signs, and submits transactions. |

The mental model: **public** stuff comes from the indexer, **private** stuff lives in your local LevelDB store, **proofs** come from the proof server, and the **wallet** ties it together by paying and signing. Once you see deployment as "these four concerns, each with a provider," the config stops looking arbitrary.

A detail that trips people on `midnight-js 4.1.1`: the private-state store wants a **password provider** (≥16 characters) and an `accountId`. Miss either and initialization fails before you ever reach the interesting part.

## Deploying one contract

With providers in hand, the deploy itself is almost anticlimactic:

```typescript
const compiled = CompiledContract.make(name, mod.Contract).pipe(
  CompiledContract.withVacantWitnesses,
  CompiledContract.withCompiledFileAssets(zkPath),
);
const contract = await deployContract(providers, {
  compiledContract: compiled,
  privateStateId: `${name}PrivateState`,
  initialPrivateState: {},
});
const d = contract.deployTxData.public;
console.log(`${name}: ${d.contractAddress} (block ${d.blockHeight}, tx ${d.txId})`);
```

You point at the compiled contract + its ZK assets, call `deployContract`, and get back a contract address, block, and tx id. To *call* it later, you `findDeployedContract` with the same compiled object and the saved address, then invoke `contract.callTx.<circuitName>(...)`.

## The gotcha: preprod history sync OOMs Node

Here's the one that cost us real time, documented so it doesn't cost you any.

Before a wallet can transact, it has to **sync**. On Midnight that includes grinding through the shielded transaction history. On a busy public network like preprod, that history is large — large enough that the sync is slow and **exhausts Node's default heap**, killing your deploy with an out-of-memory crash that looks unrelated to syncing.

Two practical responses:

**1. Give Node more heap.**

```bash
NODE_OPTIONS=--max-old-space-size=12288 npx tsx scripts/deploy-preprod.ts --network preprod --all
```

**2. Develop against a local standalone node**, where there's no deep history to grind:

```typescript
standalone: {
  networkId: 'undeployed',
  cfg: {
    indexer: 'http://localhost:8088/api/v4/graphql',
    indexerWS: 'ws://localhost:8088/api/v4/graphql/ws',
    node: 'ws://localhost:9944',
    proofServer: 'http://127.0.0.1:6300',
  },
},
```

We do nearly all iteration on standalone — deploy, call, test the full loop — and treat public-network sync as a separate, resourced step rather than something in the inner dev loop. Being honest about where we are: our contracts deploy and run end-to-end on a **local node**; the public-preprod path is gated on exactly this sync/heap issue, which is a known Midnight limitation rather than a bug in the contracts.

It helps to instrument the sync so you can *see* whether it's converging instead of staring at an opaque "syncing":

```typescript
// print applied/highest per domain so you can watch the gap shrink
const applied = p.appliedIndex ?? p.applied ?? p.synced;
const highest = p.highestIndex ?? p.targetIndex ?? p.total;
return `${applied ?? '?'}/${highest ?? '?'}`;
```

When you can watch the gap close, "is it stuck or just slow?" becomes answerable.

## Try it yourself

1. Start a local proof server (Docker, port `6300`) and a standalone node + indexer.
2. Deploy a compiled contract to `standalone`, save the returned `contractAddress`.
3. `findDeployedContract` and make one `callTx` call. You now have the full deploy → join → call cycle working locally.
4. *Then*, and only then, point at preprod with `--max-old-space-size` bumped, and watch the sync log. Budget time and RAM; don't put this in your fast feedback loop.

Deployment on Midnight has more parts than you're used to because privacy has more parts than you're used to. But each provider owns exactly one concern, and once they click into place, shipping a contract is routine — local first, public when you've resourced the sync.

---

*Part of a hands-on series on Compact + Midnight. The deploy harness above is real (`midnight-js 4.1.1`, `ledger-v8`) and runs end-to-end on a local node. Last in the series: building a privacy-first wallet feature with the Midnight wallet SDK — shielded, unshielded, and dust.*
