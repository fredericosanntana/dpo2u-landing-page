---
title: "Score-private, proof-public: prove a threshold without revealing the value"
published: false
description: "The single most useful ZK pattern for real applications: prove `secret >= threshold` while keeping the secret private. Worked through a compliance-attestation contract on Midnight, with the anti-replay binding that makes it production-safe."
tags: midnight, zeroknowledge, compact, web3
canonical_url:
cover_image:
series: "Building on Midnight"
---

Almost every real-world "can I trust you?" question reduces to the same shape: *is some private number at least as large as some bar?* Is your credit score above 700? Is your reserve above your liabilities? Is your compliance score above the audit threshold? Is your age over 18?

In every one of those, the person asking deserves a **yes/no**, and you'd rather not hand over the **exact number**. That's the canonical zero-knowledge use case, and [Midnight](https://docs.midnight.network) lets you express it directly. I call the pattern **score-private, proof-public**: the score stays a private witness, the proof that it cleared the threshold becomes public.

Here's how we built it for compliance attestations.

## The contract

```compact
export ledger attestation_verdicts: Map<Bytes<32>, Uint<8>>;     // company_id -> 1 (passed)
export ledger attestation_thresholds: Map<Bytes<32>, Uint<8>>;   // company_id -> public threshold met
export ledger attestation_contexts: Map<Bytes<32>, Bytes<32>>;   // company_id -> anti-replay context
export ledger used_contexts: Map<Bytes<32>, Uint<8>>;            // Set semantics
export ledger attestation_count: Counter;

export circuit attestCompliance(
  company_id: Bytes<32>,
  agent_did: Bytes<32>,
  policy_cid: Bytes<32>,
  threshold: Uint<8>,
  context: Bytes<32>,
  score: Uint<8>        // PRIVATE — never disclosed, never written
): [] {
  // Anti-replay: a given context may be sealed only once.
  assert(!used_contexts.member(disclose(context)), "Replay: context already used");
  // Score hygiene: a compliance score is a 0-100 percentage. `score` stays private.
  assert(score <= 100, "Invalid compliance score, must be bounded to 0-100%");
  // The core: prove score >= threshold WITHOUT disclosing the score.
  assert(score >= threshold, "Score below threshold");
  // Write only the public audit trail. The score is never written.
  used_contexts.insert(disclose(context), disclose(1 as Uint<8>));
  attestation_verdicts.insert(disclose(company_id), disclose(1 as Uint<8>));
  attestation_thresholds.insert(disclose(company_id), disclose(threshold));
  attestation_contexts.insert(disclose(company_id), disclose(context));
  attestation_count.increment(1);
}
```

Three `assert`s do all the work, and they're worth reading slowly.

**`score <= 100`** — hygiene. A compliance score is a percentage; this rejects garbage inputs. Note it constrains the *private* witness without revealing it: the proof guarantees the score was in range, but the verifier never learns where in `[0, 100]` it landed.

**`score >= threshold`** — the heart of it. This is the predicate the whole proof exists to establish. After this circuit runs, anyone checking the proof knows the company's score met the public `threshold`. They do **not** know if it scraped by at exactly `threshold` or sailed past at `100`.

**`!used_contexts.member(context)`** — anti-replay, which I'll come back to.

And then the writes: verdict `1`, the threshold, the context — all `disclose()`d into public state. The score is conspicuously absent. There is no `attestation_scores` map anywhere in the contract, and there is intentionally **no** `getComplianceScore` read. The privacy isn't a runtime policy you could misconfigure; it's the absence of any code path that could leak the number.

## Why "proof-public" matters as much as "score-private"

A lot of privacy tech stops at "hide the data." But hidden data nobody can act on is useless. The power of this pattern is the second half: the *verdict is public and verifiable*. A regulator, a counterparty, or another contract can read `attestation_verdicts[company_id] == 1` and the public `threshold`, and trust it — because it's backed by a zero-knowledge proof that some valid score cleared that bar.

So you get both properties at once:

- **The subject keeps their secret** (the exact score).
- **The world gets a trustworthy fact** (passed at threshold T).

That's strictly better than the two things people usually settle for: publishing the raw score (no privacy) or self-attesting "trust me, I passed" (no verifiability).

## The detail that makes it production-safe: anti-replay

A pure cryptographic proof of `score >= threshold` has a subtle hole: nothing stops someone from **reusing** an old valid proof, or sealing the same attestation twice. So we bind each attestation to a one-time `context`:

> `context = H(org || jurisdiction || nonce)` — computed off-chain, domain-separated, and bound on-chain.

The `used_contexts` map enforces single-use: `assert(!used_contexts.member(context))` rejects any context that's already been sealed, and we insert it immediately. Compact doesn't have a `Set` type yet, so we use a `Map` as a set (the value is a throwaway `1`). It's a small idiom, but it's the difference between "a proof" and "a proof that can't be replayed" — and it's defense-in-depth that a cryptographic-only design lacks. (There's a dedicated article in this series on the used-set pattern.)

## A subtlety worth flagging

This pattern proves the predicate held *at proving time for the prover's witness*. It does **not**, by itself, prove the score is honest — that it came from a real audit and not a number the prover made up. That's a separate concern, and the usual answer is to bind the witness to something attestable (a signed input, a committed dataset, an oracle). The ZK layer guarantees *the math*; sourcing the witness honestly is a design responsibility on top. Be honest with yourself about which guarantee you actually have.

## Try it yourself

The skeleton generalizes to any threshold proof. Swap the domain:

```compact
export ledger over_18: Map<Bytes<32>, Uint<8>>;

export circuit proveAdult(person_id: Bytes<32>, age: Uint<8>): [] {
  assert(age >= 18, "Not an adult");        // age is private
  over_18.insert(disclose(person_id), disclose(1 as Uint<8>));  // only the fact is public
}
```

Now you have age-gating that never stores anyone's age. Replace `age >= 18` with `assets >= liabilities` and you have proof-of-solvency. Replace it with `balance >= price` and you have a private payment check. The shape is always the same: **private witness, public verdict, an `assert` in between, and a one-time context if replay matters.**

Master this one pattern and you can build a startling amount of real privacy-preserving software on Midnight.

---

*Part of a hands-on series on Compact + Midnight. The contract above is real, compiles on `compactc 0.31.0`, and is unit-tested (including a test asserting no score field exists on the ledger). Next: the anti-replay used-set idiom, in depth.*
