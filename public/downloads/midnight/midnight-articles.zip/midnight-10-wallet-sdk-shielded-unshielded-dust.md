---
title: "Shielded, unshielded, and dust: building a wallet feature with the Midnight wallet SDK"
published: false
description: "A Midnight wallet juggles three sub-wallets at once. Here's what shielded, unshielded, and dust each do, how the WalletFacade composes them, and how we built a privacy-preserving transfer with a fee split on top."
tags: midnight, zeroknowledge, compact, web3
canonical_url:
cover_image:
series: "Building on Midnight"
---

A wallet on a transparent chain is conceptually one thing: keys that control a balance. A wallet on [Midnight](https://docs.midnight.network) is **three things at once**, and if you don't know that going in, the SDK looks bewildering. Once you do, it's clean. This article maps the three, shows how they compose, and builds a real transfer feature on top — drawing on what we built for an independent Midnight wallet.

## The three sub-wallets

Every Midnight account is really a coordination of three roles:

- **Shielded** — private, zero-knowledge value. Balances and transfers here are confidential. This is the privacy headline.
- **Unshielded** — public value and transparent transfers, plus the keys that sign. When you need something visible and ordinary, it lives here.
- **Dust** — the regenerating resource you spend to transact (see the [$NIGHT/$DUST article](#) in this series). Held NIGHT generates DUST; DUST pays for activity.

You derive all three from one seed, selecting the roles explicitly:

```typescript
const hd = HDWallet.fromSeed(Buffer.from(seed, 'hex'));
const result = hd.hdWallet.selectAccount(0)
  .selectRoles([Roles.Zswap, Roles.NightExternal, Roles.Dust]).deriveKeysAt(0);
const keys = result.keys;
```

`Roles.Zswap` → the shielded keys, `Roles.NightExternal` → the unshielded keys, `Roles.Dust` → the dust keys. One seed, three roles, three coordinated sub-wallets.

## The facade composes them

You don't drive the three sub-wallets by hand. The SDK's `WalletFacade` composes them behind one interface — you supply how to start each, and the facade handles the coordination:

```typescript
const wallet = await WalletFacade.init({
  configuration: walletConfig,
  shielded:   (c) => ShieldedWallet(c).startWithSecretKeys(shieldedSecretKeys),
  unshielded: (c) => UnshieldedWallet(c).startWithPublicKey(PublicKey.fromKeyStore(unshieldedKeystore)),
  dust:       (c) => DustWallet(c).startWithSecretKey(dustSecretKey, ledger.LedgerParameters.initialParameters().dust),
});
await wallet.start(shieldedSecretKeys, dustSecretKey);
```

This is the "aha" moment for most people: you initialize *all three* in one call, each with its own start strategy. The facade then gives you a unified surface — balance, build transaction, balance the transaction, finalize, submit — without you tracking which sub-wallet is doing what at each step. That composition is the whole point of the facade; embrace it rather than reaching under it.

## Building a transfer feature on top

With the facade in hand, here's a real feature: send native value, deducting a small protocol fee. The interesting parts aren't the SDK calls — they're the design decisions layered on top.

```typescript
const DEV_FEE_BPS = 15; // 0.15% = 15 basis points

calculateDevFee(amount: bigint): bigint {
  return (amount * BigInt(DEV_FEE_BPS)) / 10_000n;
}

async sendNative(to: string, amount: bigint, devFeeRecipient?: string): Promise<TxResult> {
  await this.applyTimingDelay();                  // privacy: see below

  const facade = this.wallet.getFacade();
  const keys = this.wallet.getSecretKeys();

  const devFee = this.calculateDevFee(amount);
  const netAmount = amount - devFee;

  const transfers = [{ to, amount: netAmount, tokenType: 'native' }];
  if (devFee > 0n && devFeeRecipient) {
    transfers.push({ to: devFeeRecipient, amount: devFee, tokenType: 'native' });
  }

  const tx = await facade.transferTransaction(transfers);
  const recipe = await facade.balanceUnboundTransaction(tx, keys, {
    ttl: new Date(Date.now() + 30 * 60 * 1000),
  });
  const finalized = await facade.finalizeRecipe(recipe);
  const result = await facade.submitTransaction(finalized);

  return { txId: result.txId ?? 'pending', blockHeight: result.blockHeight ?? 0, success: true };
}
```

Two things worth your attention.

**The build → balance → finalize → submit pipeline.** This four-step shape recurs across Midnight: you *describe* the transfers, the wallet *balances* it (works out inputs, fees, change), you *finalize* (proofs get attached), then you *submit*. The `ttl` you pass to balancing is a real expiry — a balanced-but-unsubmitted transaction is only valid for a window. Don't build it and sit on it.

**Fee as just another transfer.** The 0.15% fee isn't special machinery — it's a second entry in the `transfers` array, paid to a `devFeeRecipient`, computed in integer basis points (`amount * 15 / 10000`) to avoid floating point. Doing fees as ordinary transfers keeps them transparent and auditable rather than buried in custom logic.

## The privacy layer that's easy to forget

Look at the first line of `sendNative`: `await this.applyTimingDelay()`. On a privacy chain, hiding the *amount* and the *parties* isn't enough if your transactions are perfectly punctual — timing itself is a fingerprint. So the wallet can introduce a randomized delay before submitting:

```typescript
const DEFAULT_TIMING = { minDelayMs: 500, maxDelayMs: 8000 };

private async applyTimingDelay(): Promise<void> {
  if (!this.timingConfig) return;
  const { minDelayMs, maxDelayMs } = this.timingConfig;
  const delay = secureRandomInt(minDelayMs, maxDelayMs);
  await new Promise((resolve) => setTimeout(resolve, delay));
}
```

A random 0.5–8 second jitter, drawn from a *secure* RNG (not `Math.random`), so an observer can't correlate your transactions by their clockwork timing. It's a small touch, but it's the kind of thing that separates "uses a privacy chain" from "actually protects the user." Privacy is a stack of these decisions, not a single feature you switch on.

## Try it yourself

1. Initialize a `WalletFacade` with all three sub-wallets from one seed. Print each balance and convince yourself shielded, unshielded, and dust really are distinct.
2. Build a transfer and walk it through build → balance → finalize → submit, logging the recipe at each stage so you can see what balancing adds.
3. Add a fee as a second transfer entry, computed in basis points. Verify both legs land.
4. Wrap the submit in a secure randomized delay and watch your transaction timings stop being a straight line.

Three sub-wallets, one facade, a four-step pipeline, and a few deliberate privacy touches on top — that's a real Midnight wallet feature. The SDK isn't complicated once you know it's modeling three things at once; it's just honest about the fact that private money has more structure than public money.

---

*Part of a hands-on series on Compact + Midnight. The wallet code above is from a real independent Midnight wallet built on the `@midnight-ntwrk/wallet-sdk-*` packages. Thanks for following the series — go build something private.*
